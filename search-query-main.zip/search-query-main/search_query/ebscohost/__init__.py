#!/usr/bin/env python3
"""Top-level package for EBSCOHost."""

__author__ = """Gerit Wagner"""
__email__ = "gerit.wagner@hec.ca"

.. _EBSCO_0002:

EBSCO_0002 — invalid-character
==============================

**Error Code**: EBSCO_0002

**Message**: ``Search term contains invalid character``

**Description**: Search term contains invalid character

**Back to**: :ref:`lint`

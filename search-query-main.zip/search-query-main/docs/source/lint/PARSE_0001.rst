.. _PARSE_0001:

PARSE_0001 — tokenizing-failed
==============================

**Error Code**: PARSE_0001

**Message**: ``Fatal error during tokenization``

**Typical fix**: Check the query syntax and ensure it is correctly formatted.

**Back to**: :ref:`lint`

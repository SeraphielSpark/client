API
============

.. autosummary::
   :toctree: _autosummary
   :recursive:

   search_query

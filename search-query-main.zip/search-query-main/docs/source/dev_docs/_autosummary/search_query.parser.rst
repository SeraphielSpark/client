search\_query.parser
====================

.. automodule:: search_query.parser







   .. rubric:: Functions

   .. autosummary::

      get_platform
      parse

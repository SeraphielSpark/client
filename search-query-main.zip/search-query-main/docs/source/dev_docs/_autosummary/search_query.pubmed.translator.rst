search\_query.pubmed.translator
===============================

.. automodule:: search_query.pubmed.translator











   .. rubric:: Classes

   .. autosummary::

      PubmedTranslator

search\_query.upgrade
=====================

.. automodule:: search_query.upgrade







   .. rubric:: Functions

   .. autosummary::

      upgrade_query

search\_query.structured
========================

.. automodule:: search_query.structured

search\_query.linter
====================

.. automodule:: search_query.linter







   .. rubric:: Functions

   .. autosummary::

      lint_file
      lint_query_string
      pre_commit_hook

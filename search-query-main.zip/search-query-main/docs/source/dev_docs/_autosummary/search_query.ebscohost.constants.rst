search\_query.ebscohost.constants
=================================

.. automodule:: search_query.ebscohost.constants







   .. rubric:: Functions

   .. autosummary::

      generic_field_to_syntax_field
      map_to_standard
      syntax_str_to_generic_field_set

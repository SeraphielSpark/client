search\_query.generic.linter
============================

.. automodule:: search_query.generic.linter











   .. rubric:: Classes

   .. autosummary::

      GenericLinter

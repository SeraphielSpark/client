search\_query.ebscohost.translator
==================================

.. automodule:: search_query.ebscohost.translator











   .. rubric:: Classes

   .. autosummary::

      EBSCOTranslator

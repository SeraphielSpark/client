search\_query.exception
=======================

.. automodule:: search_query.exception















   .. rubric:: Exceptions

   .. autosummary::

      ListQuerySyntaxError
      QuerySyntaxError
      SearchQueryException

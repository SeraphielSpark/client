search\_query.query\_not
========================

.. automodule:: search_query.query_not











   .. rubric:: Classes

   .. autosummary::

      NotQuery

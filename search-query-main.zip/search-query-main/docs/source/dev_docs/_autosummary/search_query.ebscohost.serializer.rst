search\_query.ebscohost.serializer
==================================

.. automodule:: search_query.ebscohost.serializer











   .. rubric:: Classes

   .. autosummary::

      EBSCOQuerySerializer

search\_query.pubmed.v\_1.serializer
====================================

.. automodule:: search_query.pubmed.v_1.serializer







   .. rubric:: Functions

   .. autosummary::

      register





   .. rubric:: Classes

   .. autosummary::

      PubMedSerializer_v1

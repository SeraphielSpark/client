search\_query.wos.v\_1.translator
=================================

.. automodule:: search_query.wos.v_1.translator







   .. rubric:: Functions

   .. autosummary::

      register





   .. rubric:: Classes

   .. autosummary::

      WOSTranslator_v1

search\_query.wos.serializer
============================

.. automodule:: search_query.wos.serializer











   .. rubric:: Classes

   .. autosummary::

      WOSQuerySerializer

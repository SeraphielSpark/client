search\_query.registry
======================

.. automodule:: search_query.registry











   .. rubric:: Classes

   .. autosummary::

      Registry

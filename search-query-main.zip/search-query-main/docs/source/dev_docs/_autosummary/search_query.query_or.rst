search\_query.query\_or
=======================

.. automodule:: search_query.query_or











   .. rubric:: Classes

   .. autosummary::

      OrQuery

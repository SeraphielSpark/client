search\_query.generic.serializer
================================

.. automodule:: search_query.generic.serializer











   .. rubric:: Classes

   .. autosummary::

      GenericSerializer

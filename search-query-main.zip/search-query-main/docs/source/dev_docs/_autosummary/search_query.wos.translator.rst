search\_query.wos.translator
============================

.. automodule:: search_query.wos.translator











   .. rubric:: Classes

   .. autosummary::

      WOSTranslator

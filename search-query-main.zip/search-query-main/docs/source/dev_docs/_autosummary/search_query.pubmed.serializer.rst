search\_query.pubmed.serializer
===============================

.. automodule:: search_query.pubmed.serializer











   .. rubric:: Classes

   .. autosummary::

      PUBMEDQuerySerializer

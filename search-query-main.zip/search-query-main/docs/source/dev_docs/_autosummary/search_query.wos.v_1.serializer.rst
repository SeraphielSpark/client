search\_query.wos.v\_1.serializer
=================================

.. automodule:: search_query.wos.v_1.serializer







   .. rubric:: Functions

   .. autosummary::

      register





   .. rubric:: Classes

   .. autosummary::

      WOSSerializer_v1

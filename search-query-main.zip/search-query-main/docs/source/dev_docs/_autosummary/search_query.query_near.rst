search\_query.query\_near
=========================

.. automodule:: search_query.query_near











   .. rubric:: Classes

   .. autosummary::

      NEARQuery

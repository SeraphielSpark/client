search\_query.ebscohost.v\_1.serializer
=======================================

.. automodule:: search_query.ebscohost.v_1.serializer







   .. rubric:: Functions

   .. autosummary::

      register





   .. rubric:: Classes

   .. autosummary::

      EBCOSerializer_v1

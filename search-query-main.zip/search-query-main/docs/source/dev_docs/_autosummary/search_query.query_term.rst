search\_query.query\_term
=========================

.. automodule:: search_query.query_term











   .. rubric:: Classes

   .. autosummary::

      Term

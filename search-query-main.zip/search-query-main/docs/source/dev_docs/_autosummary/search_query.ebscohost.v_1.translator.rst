search\_query.ebscohost.v\_1.translator
=======================================

.. automodule:: search_query.ebscohost.v_1.translator







   .. rubric:: Functions

   .. autosummary::

      register





   .. rubric:: Classes

   .. autosummary::

      EBSCOTranslator_v1

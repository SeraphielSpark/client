search\_query.pubmed.v\_1.translator
====================================

.. automodule:: search_query.pubmed.v_1.translator







   .. rubric:: Functions

   .. autosummary::

      register





   .. rubric:: Classes

   .. autosummary::

      PubMedTranslator_v1

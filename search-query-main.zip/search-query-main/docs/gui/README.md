
Run (preventing CORS):
python -m http.server 8000


TODO:
- upload for search-files?
- display output nicely
- translator
- tokenizer (for debugging)
- to-structured (for debugging)
-> crowdworkers: check tokenization + query structure for the whole search-RXiv dataset.

check pyodide with pandas (even numpy?) - for bib-dedupe!

https://blog.pyodide.org/posts/pandastutor/
https://pandas.pydata.org/try.html
